/*
*   ADC Ports
*/
uint8_t A0 = 0b00000000;
uint8_t A1 = 0b00000001;
uint8_t A2 = 0b00000010;
uint8_t A3 = 0b00000011;
uint8_t A4 = 0b00000100;
uint8_t A5 = 0b00000101;

/*
*   ADC Controls
*/
uint8_t get_adc_value(uint8_t port) {
	// ref=Vcc, left adjust the result (8 bit resolution),
	// select channel 0 (PC0 = input)
	ADMUX = ((1<<REFS0)|(1<<ADLAR))|(port);
	// enable the ADC & prescale = 128
	ADCSRA = (1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
	
	ADCSRA |= (1<<ADSC); // start conversion
	loop_until_bit_is_clear(ADCSRA, ADSC);
	return ADCH; // 8-bit resolution, left adjusted
}